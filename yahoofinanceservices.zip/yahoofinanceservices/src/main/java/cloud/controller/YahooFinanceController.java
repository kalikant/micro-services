package cloud.controller;

import cloud.entities.StocksTickerResponse;
import cloud.services.FinanceCervices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;

@RestController
public class YahooFinanceController {

    @Autowired
    private FinanceCervices financeCervices;

    @GetMapping(value = "/getFinanceData", produces = "application/json")
    public StocksTickerResponse getFinanceDataFromYahooFinance() throws Exception{

        Thread.sleep(5000);

        return  financeCervices.getFinanceDataFromYahooFinance();

    }
}
