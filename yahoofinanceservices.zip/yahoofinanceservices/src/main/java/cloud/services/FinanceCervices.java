package cloud.services;

import cloud.entities.StocksTicker;
import cloud.entities.StocksTickerResponse;
import org.springframework.stereotype.Service;

import java.util.*;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class FinanceCervices {

    public StocksTickerResponse getFinanceDataFromYahooFinance(){

        List<StocksTicker> stocksTickerList=new LinkedList<>();

        stocksTickerList.add(new StocksTicker(111,"Apple Inc","APL","123 $",Calendar.getInstance().getTime()));
        stocksTickerList.add(new StocksTicker(222,"Google Inc","GOO","223 $",Calendar.getInstance().getTime()));
        stocksTickerList.add(new StocksTicker(333,"Microsoft Inc","MCR","23 $",Calendar.getInstance().getTime()));
        stocksTickerList.add(new StocksTicker(444,"IBM Inc","IBM","13 $",Calendar.getInstance().getTime()));
        stocksTickerList.add(new StocksTicker(555,"Intel Inc","ITL","133 $",Calendar.getInstance().getTime()));

        StocksTickerResponse stocksTickerResponse=new StocksTickerResponse();
        stocksTickerResponse.setStocksTickerList(stocksTickerList);

        return  stocksTickerResponse;

    }

   /* public Flux<List<StocksTickerResponse>> getFinanceDataStream(){

        List<StocksTicker> stocksTickerList=new LinkedList<>();
        Random rand = new Random();


        stocksTickerList.add(new StocksTicker(rand.nextInt(10000),"Apple Inc","APL","123 $",Calendar.getInstance().getTime()));
        stocksTickerList.add(new StocksTicker(rand.nextInt(10000),"Google Inc","GOO","223 $",Calendar.getInstance().getTime()));
        stocksTickerList.add(new StocksTicker(rand.nextInt(10000),"Microsoft Inc","MCR","23 $",Calendar.getInstance().getTime()));
        stocksTickerList.add(new StocksTicker(rand.nextInt(10000),"IBM Inc","IBM","13 $",Calendar.getInstance().getTime()));
        stocksTickerList.add(new StocksTicker(rand.nextInt(10000),"Intel Inc","ITL","133 $",Calendar.getInstance().getTime()));

        StocksTickerResponse stocksTickerResponse=new StocksTickerResponse();
        stocksTickerResponse.setStocksTickerList(stocksTickerList);

        Flux<List<StocksTickerResponse>> stocksTickerResponseFlux=stocksTickerResponse.getStocksTickerList();

        return  stocksTickerResponseFlux;


    }*/
}
