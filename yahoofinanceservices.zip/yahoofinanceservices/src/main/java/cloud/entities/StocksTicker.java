package cloud.entities;

import java.util.Date;

public class StocksTicker {

    private long stockId;
    private String stockName;
    private String ticker;
    private String value;
    private Date date;

    public StocksTicker() {
    }

    public StocksTicker(long stockId, String stockName, String ticker, String value, Date date) {
        this.stockId = stockId;
        this.stockName = stockName;
        this.ticker = ticker;
        this.value = value;
        this.date = date;
    }

    public long getStockId() {
        return stockId;
    }

    public String getStockName() {
        return stockName;
    }

    public String getTicker() {
        return ticker;
    }

    public String getValue() {
        return value;
    }

    public Date getDate() {
        return date;
    }

    public void setStockId(long stockId) {
        this.stockId = stockId;
    }

    public void setStockName(String stockName) {
        this.stockName = stockName;
    }

    public void setTicker(String ticker) {
        this.ticker = ticker;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
