package cloud.entities;

import java.util.List;

public class StocksTickerResponse {

    private List<StocksTicker> stocksTickerList;

    public List<StocksTicker> getStocksTickerList() {
        return stocksTickerList;
    }

    public void setStocksTickerList(List<StocksTicker> stocksTickerList) {
        this.stocksTickerList = stocksTickerList;
    }
}
