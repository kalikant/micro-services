package com.microservices.financeconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinanceConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinanceConsumerApplication.class, args);
	}

}
